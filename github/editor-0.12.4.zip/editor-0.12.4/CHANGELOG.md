# Change Log

All notable changes to this project will be documented in this file. See [standard-version](https://github.com/conventional-changelog/standard-version) for commit guidelines.

<a name="0.12.4"></a>
## [0.12.4](https://github.com/surveyjs/editor/compare/v0.12.3...v0.12.4) (2017-03-17)
