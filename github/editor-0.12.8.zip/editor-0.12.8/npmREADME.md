Use **surveyjs Editor** to create or edit JSON for surveyjs library.

##Getting started

Build a survey JSON using [Visual Editor](http://surveyjs.org/builder/).

Go to [SurveyJS Editor Website](http://editor.surveyjs.io/) to get the instruction for adding survey editor into your page. 

To find our more about the surveyjs library go to the [surveyjs.org site](http://surveyjs.org). 
